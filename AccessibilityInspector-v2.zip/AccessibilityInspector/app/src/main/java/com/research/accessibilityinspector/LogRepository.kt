package com.research.accessibilityinspector

import android.os.Handler
import android.os.Looper
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.CopyOnWriteArrayList

object LogRepository {

    private const val MAX_ENTRIES = 1500
    private val entries = CopyOnWriteArrayList<LogEntry>()
    private val listeners = CopyOnWriteArrayList<(LogEntry) -> Unit>()
    private val mainHandler = Handler(Looper.getMainLooper())
    val timeFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())

    var totalEventCount: Int = 0
        private set
    var lastPackageName: String = ""
        private set

    fun addEntry(entry: LogEntry) {
        totalEventCount++
        if (entry.packageName.isNotEmpty()) lastPackageName = entry.packageName
        entries.add(entry)
        if (entries.size > MAX_ENTRIES) entries.removeAt(0)
        mainHandler.post { listeners.forEach { it(entry) } }
    }

    fun log(tag: String, message: String, packageName: String = "", type: EntryType = EntryType.INFO) {
        addEntry(LogEntry(timeFormat.format(Date()), tag, message, packageName, type))
    }

    fun getAll(): List<LogEntry> = entries.toList()

    fun clear() {
        entries.clear()
        totalEventCount = 0
        lastPackageName = ""
    }

    fun addListener(l: (LogEntry) -> Unit) = listeners.add(l)
    fun removeListener(l: (LogEntry) -> Unit) = listeners.remove(l)
}

data class LogEntry(
    val timestamp: String,
    val tag: String,
    val message: String,
    val packageName: String = "",
    val type: EntryType = EntryType.INFO
) {
    fun toDisplayString() = "$timestamp [$tag] $message"
}

enum class EntryType { INFO, EVENT, NODE, DUMP, SECTION, ERROR }

package com.research.accessibilityinspector

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvPackage: TextView
    private lateinit var tvLog: TextView
    private lateinit var scrollLog: ScrollView
    private lateinit var btnGuide: Button
    private lateinit var btnDump: Button
    private lateinit var btnClear: Button
    private lateinit var cbAutoScroll: CheckBox
    private lateinit var tvEventCount: TextView

    private val handler = Handler(Looper.getMainLooper())
    private val sb = StringBuilder()
    private var lineCount = 0

    private val logListener: (LogEntry) -> Unit = { entry ->
        appendEntry(entry)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus     = findViewById(R.id.tvServiceStatus)
        tvPackage    = findViewById(R.id.tvCurrentPackage)
        tvLog        = findViewById(R.id.tvLog)
        scrollLog    = findViewById(R.id.scrollLog)
        btnGuide     = findViewById(R.id.btnStartGuide)
        btnDump      = findViewById(R.id.btnDumpScreen)
        btnClear     = findViewById(R.id.btnClearLog)
        cbAutoScroll = findViewById(R.id.cbAutoScroll)
        tvEventCount = findViewById(R.id.tvEventCount)

        btnGuide.setOnClickListener { showGuide() }

        btnDump.setOnClickListener {
            val svc = InspectorAccessibilityService.instance
            if (svc != null) {
                svc.manualDump()
                Toast.makeText(this, "Dumping...", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Service belum aktif!", Toast.LENGTH_LONG).show()
                showGuide()
            }
        }

        btnClear.setOnClickListener {
            LogRepository.clear()
            sb.clear()
            lineCount = 0
            tvLog.text = "Log cleared."
            tvEventCount.text = "Events: 0"
        }

        // Load existing log entries
        LogRepository.getAll().forEach { appendEntry(it) }
        LogRepository.addListener(logListener)

        // Poll status setiap 1.5 detik
        handler.post(object : Runnable {
            override fun run() {
                updateStatus()
                handler.postDelayed(this, 1500)
            }
        })
    }

    override fun onDestroy() {
        LogRepository.removeListener(logListener)
        super.onDestroy()
    }

    private fun appendEntry(entry: LogEntry) {
        if (lineCount > 1200) {
            sb.clear()
            sb.appendLine("[--- Log dipotong, menampilkan entri baru ---]")
            lineCount = 1
        }
        sb.appendLine(entry.toDisplayString())
        lineCount++
        tvLog.text = sb.toString()
        tvEventCount.text = "Events: ${LogRepository.totalEventCount}"
        val pkg = LogRepository.lastPackageName
        if (pkg.isNotEmpty()) tvPackage.text = "Package: $pkg"
        if (cbAutoScroll.isChecked) {
            scrollLog.post { scrollLog.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }

    private fun updateStatus() {
        val active = isServiceEnabled()
        if (active) {
            tvStatus.text = "● ACTIVE"
            tvStatus.setTextColor(ContextCompat.getColor(this, R.color.status_active))
        } else {
            tvStatus.text = "○ INACTIVE"
            tvStatus.setTextColor(ContextCompat.getColor(this, R.color.status_inactive))
        }
    }

    private fun isServiceEnabled(): Boolean {
        val am = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val list = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        val myId = "$packageName/${InspectorAccessibilityService::class.java.name}"
        return list.any { it.id == myId }
    }

    private fun showGuide() {
        val status = if (isServiceEnabled()) "✓ Service SUDAH AKTIF" else "✗ Service BELUM AKTIF"
        AlertDialog.Builder(this)
            .setTitle("Cara Aktifkan Service")
            .setMessage("""
$status

LANGKAH:
1. Tap "Buka Accessibility Settings"
2. Cari "Accessibility Inspector Service"
   (di bawah "Downloaded apps")
3. Tap → Toggle ON → Allow

Setelah aktif, buka app yang ingin
diinspeksi (misal: MT5).
Log muncul otomatis saat layar berubah.

Gunakan "Dump Screen" untuk snapshot
manual seluruh node yang aktif.

ADB (opsional):
adb logcat -s A11yInspector:D
            """.trimIndent())
            .setPositiveButton("Buka Accessibility Settings") { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNegativeButton("Tutup", null)
            .show()
    }
}

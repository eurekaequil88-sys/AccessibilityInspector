package com.research.accessibilityinspector

import android.graphics.Rect
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo

object NodeDumper {

    private const val TAG = "A11yInspector"
    private const val MAX_DEPTH = 40

    fun dumpTree(root: AccessibilityNodeInfo?, packageName: String, isManualDump: Boolean = false): Int {
        if (root == null) {
            LogRepository.log("DUMP", "ERROR: root node null - tidak ada window aktif", packageName, EntryType.ERROR)
            return 0
        }
        val label = if (isManualDump) "MANUAL DUMP" else "AUTO DUMP"
        LogRepository.log("DUMP", "=".repeat(55), packageName, EntryType.SECTION)
        LogRepository.log("DUMP", "$label -> Package: $packageName", packageName, EntryType.EVENT)
        LogRepository.log("DUMP", "=".repeat(55), packageName, EntryType.SECTION)
        Log.i(TAG, "===== $label pkg=$packageName =====")

        var count = 0
        traverseNode(root, 0, packageName, isManualDump) { count++ }

        LogRepository.log("DUMP", "Total nodes ditemukan: $count", packageName, EntryType.SECTION)
        LogRepository.log("DUMP", "-".repeat(55), packageName, EntryType.SECTION)
        root.recycle()
        return count
    }

    private fun traverseNode(
        node: AccessibilityNodeInfo,
        depth: Int,
        pkg: String,
        isManualDump: Boolean,
        counter: () -> Unit
    ) {
        if (depth > MAX_DEPTH) return
        counter()

        val indent = if (depth == 0) "" else "  ".repeat(depth - 1) + "  +-"
        val className = node.className?.toString()?.substringAfterLast('.') ?: "?"
        val text = node.text?.toString()?.trim() ?: ""
        val desc = node.contentDescription?.toString()?.trim() ?: ""
        val viewId = node.viewIdResourceName?.substringAfter(":") ?: ""
        val bounds = Rect().also { node.getBoundsInScreen(it) }.let { "${it.left},${it.top}-${it.right},${it.bottom}" }

        val flags = buildList {
            if (node.isClickable) add("CLICK")
            if (node.isEnabled) add("ON") else add("OFF")
            if (node.isVisibleToUser) add("VIS")
            if (node.isScrollable) add("SCROLL")
            if (node.isCheckable) add("CHECK")
            if (node.isPassword) add("PWD")
        }.joinToString("|")

        val line = buildString {
            append("$indent[$depth] $className")
            if (text.isNotEmpty()) append(" | \"$text\"")
            if (desc.isNotEmpty()) append(" | desc:\"$desc\"")
            if (viewId.isNotEmpty()) append(" | $viewId")
            append(" | [$flags] | $bounds")
        }

        val type = if (isManualDump) EntryType.DUMP else EntryType.NODE
        LogRepository.log("NODE", line, pkg, type)
        Log.d(TAG, line)

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            traverseNode(child, depth + 1, pkg, isManualDump, counter)
            child.recycle()
        }
    }
}

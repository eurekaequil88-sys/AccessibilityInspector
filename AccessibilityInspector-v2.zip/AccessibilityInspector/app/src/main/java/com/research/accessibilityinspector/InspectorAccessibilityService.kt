package com.research.accessibilityinspector

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent

class InspectorAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "A11yService"
        @Volatile var instance: InspectorAccessibilityService? = null
            private set
        private const val THROTTLE_MS = 3000L
    }

    private var lastContentDump = 0L
    private var lastContentPkg = ""

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        LogRepository.log("SERVICE", "Service AKTIF dan terhubung", type = EntryType.EVENT)
        LogRepository.log("SERVICE", "Siap memantau Accessibility Tree", type = EntryType.INFO)
        Log.i(TAG, "Service connected")
    }

    override fun onInterrupt() {
        LogRepository.log("SERVICE", "Service INTERRUPTED", type = EntryType.ERROR)
    }

    override fun onDestroy() {
        instance = null
        LogRepository.log("SERVICE", "Service BERHENTI", type = EntryType.ERROR)
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val event = event ?: return
        val pkg = event.packageName?.toString() ?: return

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                val cls = event.className?.toString() ?: ""
                val txt = event.text?.joinToString(", ") ?: ""
                LogRepository.log("WINDOW", "=".repeat(50), pkg, EntryType.SECTION)
                LogRepository.log("WINDOW", "WINDOW CHANGED: $pkg", pkg, EntryType.EVENT)
                LogRepository.log("WINDOW", "  Class: $cls", pkg, EntryType.INFO)
                if (txt.isNotEmpty())
                    LogRepository.log("WINDOW", "  Text: $txt", pkg, EntryType.INFO)
                dumpWindow(pkg, isManual = false)
            }

            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                val now = System.currentTimeMillis()
                if (now - lastContentDump > THROTTLE_MS || pkg != lastContentPkg) {
                    lastContentDump = now
                    lastContentPkg = pkg
                    LogRepository.log("CONTENT", "Konten berubah: $pkg", pkg, EntryType.INFO)
                }
            }

            AccessibilityEvent.TYPE_VIEW_CLICKED -> {
                val txt = event.text?.joinToString() ?: ""
                val desc = event.contentDescription?.toString() ?: ""
                if (txt.isNotEmpty() || desc.isNotEmpty()) {
                    LogRepository.log("CLICK", "[$pkg] text=\"$txt\" desc=\"$desc\"", pkg, EntryType.INFO)
                }
            }
        }
    }

    private fun dumpWindow(pkg: String, isManual: Boolean) {
        val root = getRootInActiveWindow()
        val actualPkg = if (pkg.isNotEmpty()) pkg else root?.packageName?.toString() ?: "unknown"
        NodeDumper.dumpTree(root, actualPkg, isManual)
    }

    fun manualDump() {
        LogRepository.log("MANUAL", "Manual dump diminta user", type = EntryType.EVENT)
        dumpWindow("", isManual = true)
    }
}
